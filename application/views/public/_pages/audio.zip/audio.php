<style type="text/css">
  .audio-download{
        float: right;
    font-size: 22px;
  }
</style>
<?php if($CI->ion_auth->logged_in()): ?> 
  <section class="page-section-ptb"> 
    <div class="container"> 
  
    	<?php  
    	$sql = "SELECT a.`id` aid,a.`slug`  aslug,a.`title` atitle,a.`audio` aaudio,a.`created` acreated,a.`last_update` alastupdate,p.`slug` pslug,p.`title` ptitle FROM `audio` as `a`  left join `category` as `p` on a.`category` = p.`id` WHERE a.`active` = '1' AND a.`published` = '1'  ORDER BY p.`id` DESC limit 8"; 
  
    	$audios = $CI->db->query($sql)->result_array(); 
  
    	foreach ($audios as $value) { 
    		$allAudios[$value['pslug']][] = $value; 
    	} 
    	 
  
    	foreach ($allAudios as $category => $singleAudio) { ?> 
  
 <div class="col-lg-12 col-md-12"> 
 	<div class="title mt-30 mb-30"> 
 		<h6><?php echo $singleAudio[0]['ptitle'] ?></h6> 
 	</div> 
 	<div class="owl-carousel" data-nav-dots="false" data-nav-arrow="true" data-items="4" data-sm-items="4" data-lg-items="4" data-md-items="4" data-xs-items="2" data-autoplay="false" data-loop="false"> 
 		<?php foreach ($singleAudio as  $data): ?> 
 			<div class="item"> 
 				<div class="product"> 
 					<div class="product-image"> 
 						<audio controls style="width:100%;" controlsList="nodownload"> 
 							<source src="<?php echo base_url('uploads/audio/'.$data['aaudio']); ?> " type="audio/mp3"> 
 							<source src="<?php echo base_url('uploads/audio/'.$data['aaudio']); ?> " type="audio/ogg"> 
 							<source src="<?php echo base_url('uploads/audio/'.$data['aaudio']); ?> " type="audio/mpeg"> 
 						</audio> 
 					</div> 
 					<div class="product-des"> 
 						<div class="product-title"> <a href="<?php echo base_url('audio/'.$data['aslug']); ?>"><?php echo $data['atitle'] ?></a> <a href="<?php echo base_url('uploads/audio/'.$data['aaudio']); ?> " download><i class="fa fa-download audio-download"></i></a>
 						</div> 
  
  
 						<?php if(($data['alastupdate']) == 0): ?> 
 							<span><i><?php echo time_ago($data['acreated']); ?></i></span>  
 						<?php else: ?> 
 							<span><i>updated: <?php echo time_ago($data['alastupdate']); ?></i></span>  
 						<?php endif; ?> 
  
  
 					</div> 
 				</div> 
 			</div> 
 		<?php endforeach ?> 
 		 
  
 	</div> 
 </div> 
  
    	<?php 	} ?> 
  
  
  
    </div> 
 </section> 
 <?php else: ?> 
 	<style type="text/css"> 
 		.error-block .error-text h2{ 
 			font-size: 198px; 
 		} 
 	</style> 
 <section class="page-section-ptb"> 
 	<div class="container"> 
             <div class="row justify-content-center"> 
                 <div class="col-lg-10 text-center"> 
                      <div class="error-block text-center clearfix"> 
                       <div class="error-text"> 
                         <h2>Required</h2> 
                       </div> 
                       <h1 class="theme-color mb-40">Login</h1> 
                       <p>This Page You Are Accessing Not visible For Visitors.</p> 
                    </div>    
                     <div class="error-info"> 
                         <a class="button xs-mb-10" href="<?php echo base_url('login'); ?>">Login</a> 
                         <a class="button button-border black" href="<?php echo base_url(); ?>">back to home</a> 
                     </div> 
                 </div> 
             </div> 
         </div> 
 </section> 
 <?php endif; ?> 
