      
    <section class="page-section-ptb">   
      <div class="container">   
      
       <?php  
         if(!isset($playlist_videos)){
           $sql = "SELECT * FROM `video` WHERE `active` = '1' AND `published` = '1'  ORDER BY `id` DESC limit 9";//limit 8   
          
           $videos = $CI->db->query($sql)->result_array();
         }else{
           $videos = $playlist_videos;
         }
           $selectedPlaylist = $CI->uri->segment(3);

       $sql = "SELECT p.`id` id,p.`slug`  slug,p.`title` title,p.`content` content FROM `category`  as `p` WHERE p.`active` = '1' AND p.`category` = 'video'  ORDER BY p.`id` DESC ";//limit 8   
      
       $categories = $CI->db->query($sql)->result_array();   
      
       // foreach ($videos as $value) {   
       //   $allVideos[$value['pslug']][] = $value;   
       // }   
        ?>


<?php if(isset($playlist_videos))
        // var_dump($playlist_videos);
 ?>

<div class="section-title text-center">
  <p>Please click on the drop down menu to see the list of our complete video collection. You can view the video by clicking on its image or title .</p>
</div>

      
    <select class="selectpicker" data-width="100%" id="playlist"><!-- data-live-search="true" -->
      <option value="recent">Recent</option>
      <?php foreach ($categories as  $single): ?>
      <option value="<?php echo $single['slug'] ?>" data-subtext="<?php echo $single['content'] ?>" <?php echo ($selectedPlaylist == $single['slug'])?'selected':''; ?>><?php echo $single['title'] ?></option>
       <?php endforeach ?> 
    </select>

 <!--=================================
 blog -->
<section class="white-bg page-section-ptb">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h4 class="fw-7 mb-30"><?php echo !isset($playlist_videos)?'Recent Uploads':'Playlist Videos'?> </h4>
      </div>
    </div>
    <div class="row" id="all_videos">
      <?php if(count($videos)): ?>
      <?php foreach($videos as $video): ?>
      <div class="col-md-4">
         <div class="blog-box blog-2 blog-border">          
            <div class="popup-video-image border-video popup-gallery">
              <img class="img-fluid" src="<?php echo $CI->_baseUrl.'uploads/'.$video['thumbnail']; ?>" alt="">
                <a class="popup-youtube" href="https://www.youtube.com/watch?v=<?php echo $video['url']; ?>"> <i class="fa fa-play"></i> </a>
            </div> 
            <div class="blog-info">
              <h4 class="mt-20"> <a href="<?php echo $CI->_baseUrl.'video/'.$video['slug']; ?>"><?php echo $video['title']; ?></a></h4>  
              <p><?php echo $video['excerpt']; ?></p>  
              <a class="button arrow" href="<?php echo $CI->_baseUrl.'video/'.$video['slug']; ?>">Read More<i class="fa fa-angle-right" aria-hidden="true"></i></a>        
         </div>           
        </div>
      </div>
    <?php endforeach; ?>
    <?php else: ?>
      <div class="col-md-12" style="text-align: center;">
        <h1 class="fw-7 mb-30">Empty playlist</h1>
      </div>
    <?php endif; ?>
    </div>
  </div>
</section>

 <!--=================================
 blog -->






      
      </div>   
   </section>   



<script type="text/javascript">
  $(document).ready(function(){



    // $("#playlist").on('changed.bs.select', function (e, clickedIndex, isSelected, previousValue) {
    //    $.ajax({
    //         method: "POST",
    //         url: "<?php echo $CI->_baseUrl?>/AjaxRequests/videoPlaylist/"+$(this).val(),
    //         // url:'users.xml', // when use the xml in dataType

    //         dataType: "json", // Change this to "text" and you will see the difference if data not required form then .done function not work
    //         success: function (data) { 
    //           // console.log(data.length);
    //           html = '';
    //           $.each(data, function(index, element) {
    //               html += '<div class="col-md-4"><div class="blog-box blog-2 blog-border"><div class="popup-video-image border-video popup-gallery"> <img class="img-fluid" src="<?php echo $CI->_baseUrl?>/uploads/'+element.thumbnail+'" alt=""> <a class="popup-youtube" href="https://www.youtube.com/watch?v=LgvseYYhqU0"> <i class="fa fa-play"></i> </a></div><div class="blog-info"><h4 class="mt-20"> <a href="#"> Does your life lack meaning</a></h4><p>Detail of the video</p> <a class="button arrow" href="http://localhost/finalazz/welfare/this-is-the">Read More<i class="fa fa-angle-right" aria-hidden="true"></i></a></div></div></div>';
                  
                 
    //           });
    //           $("#all_videos").html(html);
    //         }
    //     });
    // });


    $("#playlist").on('changed.bs.select', function (e, clickedIndex, isSelected, previousValue) {
      var id = $(this).val();
      if(id == 'recent'){
        location.href = base_url+"video/";
      }else{
        location.href = base_url+"video/playlist/"+id;

      }
    });
  });

</script>